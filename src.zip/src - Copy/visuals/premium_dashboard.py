"""
Premium Dashboard v2 — World-Class Autonomous Drone Command Center
====================================================================
Professional-grade UI combining:
  - Tesla Mission Control aesthetic
  - Apple Human Interface guidelines
  - NASA Mission Control layout
  - Formula 1 telemetry clarity
  - Bloomberg Terminal information density
  - Modern aerospace cockpit design

All existing functionality preserved. Presentation completely transformed.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Any

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.collections import PathCollection
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import (
    FancyBboxPatch, Circle, FancyArrowPatch, Rectangle, Arc, Wedge,
)
from matplotlib.text import Text

from .camera_system import CameraSystem, CameraMode
from .vision_engine import VisionEngine

# ── Global singleton ─────────────────────────────────────────────────────────
_premium_dashboard: Optional["PremiumDashboard"] = None


# ══════════════════════════════════════════════════════════════════════════════
# PREMIUM COLOR SYSTEM — Professional aerospace palette
# ══════════════════════════════════════════════════════════════════════════════

class PColor:
    # Backgrounds
    BG_DARK = "#05070B"
    BG_PANEL = "#0B0E14"
    BG_INNER = "#11151F"
    BG_GLASS = "#11151F"
    BG_CARD = "#0D1019"

    # Borders & Glows
    BORDER = "#1A2035"
    BORDER_GLOW = "#00D4FF"
    BORDER_ACTIVE = "#0A1A2A"

    # Primary Accents
    PRIMARY = "#00D4FF"
    SECONDARY = "#9D6CFF"
    SUCCESS = "#00FF88"
    WARNING = "#FFC857"
    DANGER = "#FF4D5A"
    INFO = "#00D4FF"
    PURPLE = "#9D6CFF"

    # Brand Colors
    DRONE = "#FF8800"
    DRONE_GLOW = "#FF5500"
    TARGET = "#00FF88"
    PATH = "#00D4FF"
    PATH_GLOW = "#0088CC"
    TRAIL = "#FF6633"
    OBSTACLE = "#FF3333"
    DYNAMIC = "#FF8800"
    SENSOR = "#3366FF"
    BUILDING = "#4A5568"
    WATER = "#1A365D"
    FOREST = "#1A4730"
    LANDING = "#00CC66"

    # Text Hierarchy
    TEXT_MAIN = "#FFFFFF"
    TEXT_BRIGHT = "#FFFFFF"
    TEXT_VALUE = "#F0F4FF"
    TEXT_SECTION = "#A0B0D0"
    TEXT_LABEL = "#6B7FA0"
    TEXT_ACCENT = "#00D4FF"
    TEXT_DIM = "#4A5A78"
    TEXT_MUTED = "#2A3A55"

    # Chart Colors
    LINE_RISK = "#FF4D5A"
    LINE_MEMORY = "#FFC857"
    LINE_ATTENTION = "#00D4FF"
    LINE_COGNITIVE = "#00FF88"
    LINE_BATTERY = "#9D6CFF"
    LINE_SPEED = "#FF8800"
    LINE_CONFIDENCE = "#00FF88"

    # Status Colors
    STATUS_OK = "#00FF88"
    STATUS_WARN = "#FFC857"
    STATUS_ERR = "#FF4D5A"
    STATUS_OFF = "#2A3A55"


# ── Constants ───────────────────────────────────────────────────────────────
MAX_TRAIL = 800
FPS_SMOOTH = 0.05
MAX_HISTORY = 500


class PremiumDashboard:
    """World-class autonomous drone command center dashboard."""

    def __init__(
        self,
        world_width: float = 100,
        world_height: float = 100,
        use_theme: str = "dark",
    ):
        plt.ion()

        self.fig = plt.figure(
            figsize=(24.0, 14.0),
            num="MJN DRONE — Autonomous Command Center",
            facecolor=PColor.BG_DARK,
            dpi=120,
        )

        self.world_width = world_width
        self.world_height = world_height
        self.theme = use_theme

        self.camera = CameraSystem()
        self.vision = VisionEngine()
        self.camera.set_viewport(world_width, world_height)

        # ── Layout: 24-column grid ──
        self._setup_layout()

        # State
        self.trail: List[Tuple[float, float]] = []
        self._fps: float = 60.0
        self._last_t: float = time.perf_counter()
        self._frame_count: int = 0
        self._init_done: bool = False
        self._bg_cache = None
        self._actual_dt: float = 0.016

        # History buffers
        self._h_risk: List[float] = []
        self._h_mem: List[float] = []
        self._h_att: List[float] = []
        self._h_cog: List[float] = []
        self._h_bat: List[float] = []
        self._h_spd: List[float] = []
        self._h_conf: List[float] = []
        self._h_cpu: List[float] = []
        self._h_lat: List[float] = []

        self.mission_progress: float = 0.0
        self.mission_eta: str = "--:--"
        self.mission_start_time: float = time.time()

        self._create_artists()
        self.fig.canvas.draw()
        self._bg_cache = self.fig.canvas.copy_from_bbox(self.fig.bbox)
        self._init_done = True
        self.vision.daynight_speed = 0.004

    def _setup_layout(self):
        """12-column clean grid layout - no overlapping guaranteed."""
        gs = GridSpec(
            12, 12, figure=self.fig,
            left=0.01, right=0.99,
            top=0.98, bottom=0.01,
            hspace=0.3, wspace=0.25,
        )

        # ── Top Bar (row 0, all columns) ──
        self._ax_topbar = self.fig.add_subplot(gs[0, :])

        # ── World Viewport (rows 1-7, cols 0-8) ──
        self._ax_viewport = self.fig.add_subplot(gs[1:8, 0:9])

        # ── Right Panel (rows 1-7, cols 9-11) ──
        self._ax_right = self.fig.add_subplot(gs[1:8, 9:12])

        # ── Bottom Panels (rows 8-11) ──
        self._ax_bottom_left = self.fig.add_subplot(gs[8:11, 0:6])
        self._ax_bottom_right = self.fig.add_subplot(gs[8:11, 6:12])

        # ── Legend (row 11, all columns) ──
        self._ax_legend = self.fig.add_subplot(gs[11, :])

        self._all_axes = [
            self._ax_topbar, self._ax_viewport, self._ax_legend,
            self._ax_right, self._ax_bottom_left, self._ax_bottom_right,
        ]
        self._style_axes()

    def _style_axes(self):
        """Apply premium styling to all panels."""
        # Top Bar
        self._ax_topbar.set_facecolor(PColor.BG_PANEL)
        self._ax_topbar.axis("off")
        for s in self._ax_topbar.spines.values():
            s.set_color(PColor.BORDER)
            s.set_linewidth(0.5)

        # Viewport
        self._ax_viewport.set_facecolor(PColor.BG_DARK)
        self._ax_viewport.set_aspect("equal", adjustable="box")
        self._ax_viewport.tick_params(
            bottom=False, left=False, labelbottom=False, labelleft=False,
        )
        for s in self._ax_viewport.spines.values():
            s.set_color(PColor.BORDER_ACTIVE)
            s.set_linewidth(0.5)

        # Legend
        self._ax_legend.set_facecolor(PColor.BG_PANEL)
        self._ax_legend.axis("off")
        for s in self._ax_legend.spines.values():
            s.set_color(PColor.BORDER)
            s.set_linewidth(0.3)

        # Right panel (single scrollable card area)
        self._ax_right.set_facecolor(PColor.BG_CARD)
        self._ax_right.axis("off")
        frame = FancyBboxPatch(
            (0, 0), 1, 1,
            boxstyle=mpatches.BoxStyle("Round", pad=0.01),
            facecolor="none", edgecolor=PColor.BORDER,
            linewidth=0.8, transform=self._ax_right.transAxes, zorder=0,
        )
        self._ax_right.add_patch(frame)

        # Bottom panels
        for ax in [self._ax_bottom_left, self._ax_bottom_right]:
            ax.set_facecolor(PColor.BG_CARD)
            frame = FancyBboxPatch(
                (0, 0), 1, 1,
                boxstyle=mpatches.BoxStyle("Round", pad=0.01),
                facecolor="none", edgecolor=PColor.BORDER,
                linewidth=0.8, transform=ax.transAxes, zorder=0,
            )
            ax.add_patch(frame)
            ax.axis("off")

    def _create_artists(self):
        self._create_topbar()
        self._create_viewport_artists()
        self._create_legend()
        self._create_right_panel(self._ax_right)
        self._create_metrics_graph(self._ax_bottom_left)
        self._create_brain_panel(self._ax_bottom_right)

    # ══════════════════════════════════════════════════════════════════════════
    # TOP BAR
    # ══════════════════════════════════════════════════════════════════════════

    def _create_topbar(self):
        ax = self._ax_topbar
        # Project name
        ax.text(0.005, 0.5, "MJN DRONE", transform=ax.transAxes,
                fontsize=12, fontweight="bold", color=PColor.PRIMARY,
                va="center", family="sans-serif")
        ax.text(0.08, 0.5, "AUTONOMOUS COMMAND CENTER", transform=ax.transAxes,
                fontsize=8, fontweight="normal", color=PColor.TEXT_DIM,
                va="center", family="sans-serif")

        # Status indicators
        status_items = [
            (0.35, "MISSION", "ACTIVE", PColor.STATUS_OK),
            (0.48, "CONNECTION", "ONLINE", PColor.STATUS_OK),
            (0.60, "MODE", "AUTONOMOUS", PColor.INFO),
            (0.72, "EMERGENCY", "NORMAL", PColor.STATUS_OK),
        ]
        for x, label, value, color in status_items:
            ax.text(x, 0.65, label, transform=ax.transAxes,
                    fontsize=5.5, color=PColor.TEXT_LABEL,
                    va="center", family="sans-serif")
            ax.text(x, 0.35, value, transform=ax.transAxes,
                    fontsize=7, fontweight="bold", color=color,
                    va="center", family="monospace")

        # Time & FPS (right side)
        self._tb_fps = ax.text(0.90, 0.65, "60 FPS", transform=ax.transAxes,
                               fontsize=7, fontweight="bold", color=PColor.TEXT_VALUE,
                               va="center", family="monospace")
        self._tb_time = ax.text(0.90, 0.35, "00:00", transform=ax.transAxes,
                                fontsize=7, fontweight="bold", color=PColor.TEXT_ACCENT,
                                va="center", family="monospace")
        ax.text(0.98, 0.5, "v2.0", transform=ax.transAxes,
                fontsize=6, color=PColor.TEXT_MUTED,
                va="center", ha="right", family="sans-serif")

    # ══════════════════════════════════════════════════════════════════════════
    # VIEWPORT
    # ══════════════════════════════════════════════════════════════════════════

    def _create_viewport_artists(self):
        ax = self._ax_viewport

        # Terrain
        self._v_terrain = ax.imshow(
            np.zeros((20, 20, 3)), origin="lower",
            interpolation="bilinear", aspect="equal", alpha=0.9, zorder=0,
        )
        self._v_topo = ax.imshow(
            np.zeros((20, 20)), origin="lower",
            interpolation="bilinear", aspect="equal",
            cmap="terrain", alpha=0.10, zorder=1,
        )

        # World objects as scatter plots
        self._v_buildings = ax.scatter([], [], marker="s", s=20, c=PColor.BUILDING,
                                        edgecolors="#3A4555", linewidths=0.3, alpha=0.7, zorder=2)
        self._v_trees = ax.scatter([], [], marker="^", s=8, c=PColor.FOREST,
                                    alpha=0.5, linewidths=0, zorder=2)
        self._v_obstacles = ax.scatter([], [], s=10, c=PColor.OBSTACLE,
                                        edgecolors="#661111", linewidths=0.3, alpha=0.6, zorder=3)
        self._v_dynamic = ax.scatter([], [], marker="D", s=50, c=PColor.DYNAMIC,
                                      edgecolors="#883300", linewidths=0.5, zorder=4)
        self._v_vehicles = ax.scatter([], [], marker="s", s=15, c=PColor.PRIMARY,
                                       edgecolors="#003366", linewidths=0.3, zorder=4)
        self._v_pedestrians = ax.scatter([], [], marker="o", s=6, c=PColor.WARNING,
                                          alpha=0.6, linewidths=0, zorder=4)
        self._v_birds = ax.scatter([], [], marker="v", s=8, c=PColor.TEXT_DIM,
                                    alpha=0.4, linewidths=0, zorder=3)
        self._v_pads = ax.scatter([], [], marker="H", s=80, c=PColor.LANDING,
                                   edgecolors="#004422", linewidths=0.8, zorder=3)

        # Paths
        self._v_path = ax.plot([], [], "-", linewidth=2, color=PColor.PATH,
                                alpha=0.6, zorder=4, solid_capstyle="round")[0]
        self._v_path_glow = ax.plot([], [], "-", linewidth=5, color=PColor.PATH_GLOW,
                                     alpha=0.15, zorder=3, solid_capstyle="round")[0]
        self._v_trail = ax.plot([], [], "-", linewidth=1.5, color=PColor.TRAIL,
                                 alpha=0.5, zorder=4, solid_capstyle="round")[0]
        self._v_predicted = ax.plot([], [], ":", linewidth=1, color=PColor.PATH,
                                     alpha=0.2, zorder=3)[0]

        # Sensor circle
        self._v_sensor = Circle((0, 0), 5, fill=False, linestyle="--",
                                linewidth=0.8, color=PColor.SENSOR, alpha=0.3, zorder=3)
        ax.add_patch(self._v_sensor)
        self._v_sensor_fill = Circle((0, 0), 5, fill=True, facecolor=PColor.SENSOR,
                                      alpha=0.03, edgecolor="none", zorder=2)
        ax.add_patch(self._v_sensor_fill)

        # Drone
        self._v_drone_body = Circle((0, 0), 1.0, fill=True, facecolor=PColor.DRONE,
                                     edgecolor=PColor.DRONE_GLOW, linewidth=1.5, alpha=0.95, zorder=10)
        ax.add_patch(self._v_drone_body)
        self._v_drone_heading = ax.plot([], [], "-", linewidth=2, color=PColor.DRONE_GLOW,
                                          alpha=0.8, zorder=11, solid_capstyle="round")[0]
        self._v_drone_glow = Circle((0, 0), 2.0, fill=True, facecolor=PColor.DRONE,
                                      alpha=0.10, edgecolor="none", zorder=9)
        ax.add_patch(self._v_drone_glow)

        # Target
        self._v_target_cross = ax.plot([], [], "+", markersize=14, markeredgewidth=2,
                                        color=PColor.TARGET, alpha=0.7, zorder=9)[0]
        self._v_target_glow = Circle((0, 0), 1.5, fill=True, facecolor=PColor.TARGET,
                                      alpha=0.15, edgecolor="none", zorder=8)
        ax.add_patch(self._v_target_glow)

        # Camera badge (compact)
        self._v_cam_badge = ax.text(0.01, 0.97, "CHASE", transform=ax.transAxes,
                                     fontsize=7, fontweight="bold", color=PColor.TEXT_BRIGHT,
                                     va="top", family="monospace",
                                     bbox=dict(boxstyle="round,pad=0.2", facecolor=PColor.BG_GLASS,
                                               edgecolor=PColor.BORDER_GLOW, linewidth=0.5))

        # FPS in viewport
        self._v_fps = ax.text(0.01, 0.01, "60 FPS", transform=ax.transAxes,
                               fontsize=7, fontweight="bold", color=PColor.TEXT_ACCENT,
                               ha="left", va="bottom", family="monospace",
                               bbox=dict(boxstyle="round,pad=0.15", facecolor=PColor.BG_GLASS,
                                         edgecolor="none", alpha=0.5))

        # Coordinate display
        self._v_coords = ax.text(0.99, 0.01, "(0, 0)", transform=ax.transAxes,
                                  fontsize=6, color=PColor.TEXT_DIM,
                                  ha="right", va="bottom", family="monospace")

    # ══════════════════════════════════════════════════════════════════════════
    # LEGEND
    # ══════════════════════════════════════════════════════════════════════════

    def _create_legend(self):
        leg_ax = self._ax_legend
        items = [
            ("Drone", "o", PColor.DRONE, None),
            ("Target", "+", PColor.TARGET, None),
            ("Path", "-", PColor.PATH, None),
            ("Trail", "-", PColor.TRAIL, None),
            ("Building", "s", PColor.BUILDING, None),
            ("Tree", "^", PColor.FOREST, None),
            ("Static Obs", "s", PColor.OBSTACLE, "#661111"),
            ("Dynamic Obs", "D", PColor.DYNAMIC, "#883300"),
            ("Vehicle", "s", PColor.PRIMARY, "#003366"),
            ("Pedestrian", "o", PColor.WARNING, None),
            ("Bird", "v", PColor.TEXT_DIM, None),
            ("Landing Pad", "H", PColor.LANDING, "#004422"),
            ("Sensor", "--", PColor.SENSOR, None),
        ]
        handles = []
        for label, marker, color, edge in items:
            if marker == "-":
                h = Line2D([0], [0], color=color, linewidth=2, label=label)
            elif marker == "--":
                h = Line2D([0], [0], color=color, linewidth=1, linestyle="--", label=label)
            else:
                h = Line2D([0], [0], marker=marker, color="w",
                           markerfacecolor=color, markeredgecolor=edge or color,
                           markersize=5, label=label, linestyle="None")
            handles.append(h)

        leg = leg_ax.legend(handles=handles, loc="center",
                            fontsize=5.5, frameon=True, framealpha=0.8,
                            facecolor=PColor.BG_INNER, edgecolor=PColor.BORDER,
                            labelcolor=PColor.TEXT_SECTION,
                            ncol=13, columnspacing=0.8, handletextpad=0.3,
                            borderpad=0.3)
        leg.get_frame().set_linewidth(0.3)

    # ══════════════════════════════════════════════════════════════════════════
    # FLIGHT DATA CARD
    # ══════════════════════════════════════════════════════════════════════════

    def _create_flight_card(self):
        ax = self._ax_flight
        # Title
        ax.text(0.05, 0.90, "FLIGHT DATA", transform=ax.transAxes,
                fontsize=7, fontweight="bold", color=PColor.PRIMARY,
                va="top", family="sans-serif")
        ax.plot([0.05, 0.95], [0.82, 0.82], transform=ax.transAxes,
                color=PColor.BORDER, linewidth=0.5)

        # Labels & Values
        labels_left = ["SPEED", "HEADING", "ALTITUDE"]
        labels_right = ["VERT SPD", "BANK", "SIGNAL"]
        self._f_vals = {}

        for i, (lbl, lbl_r) in enumerate(zip(labels_left, labels_right)):
            y = 0.72 - i * 0.18
            # Left
            ax.text(0.05, y + 0.04, lbl, transform=ax.transAxes,
                    fontsize=5, color=PColor.TEXT_LABEL, va="bottom", family="sans-serif")
            v = ax.text(0.05, y - 0.04, "--", transform=ax.transAxes,
                        fontsize=10, fontweight="bold", color=PColor.TEXT_VALUE,
                        va="top", family="monospace")
            self._f_vals[lbl] = v
            # Right
            ax.text(0.50, y + 0.04, lbl_r, transform=ax.transAxes,
                    fontsize=5, color=PColor.TEXT_LABEL, va="bottom", family="sans-serif")
            v = ax.text(0.50, y - 0.04, "--", transform=ax.transAxes,
                        fontsize=10, fontweight="bold", color=PColor.TEXT_VALUE,
                        va="top", family="monospace")
            self._f_vals[lbl_r] = v

    def _update_flight(self, speed, heading, dist, v_speed, bank, signal):
        vals = {
            "SPEED": f"{speed:.1f} m/s", "HEADING": f"{heading:.0f}°",
            "ALTITUDE": f"{dist:.0f} m", "VERT SPD": f"{v_speed:.1f} m/s",
            "BANK": f"{bank:.1f}°", "SIGNAL": f"{signal}%",
        }
        for key, v in vals.items():
            if key in self._f_vals:
                self._f_vals[key].set_text(v)

    # ══════════════════════════════════════════════════════════════════════════
    # NAVIGATION CARD
    # ══════════════════════════════════════════════════════════════════════════

    def _create_nav_card(self):
        ax = self._ax_nav
        ax.text(0.05, 0.90, "NAVIGATION", transform=ax.transAxes,
                fontsize=7, fontweight="bold", color=PColor.INFO,
                va="top", family="sans-serif")
        ax.plot([0.05, 0.95], [0.82, 0.82], transform=ax.transAxes,
                color=PColor.BORDER, linewidth=0.5)

        labels = ["PLANNER", "MISSION", "WAYPOINTS", "ETA", "PATH LEN", "EXPLORED"]
        self._n_vals = {}
        for i, lbl in enumerate(labels):
            col = i % 2
            row = i // 2
            x = 0.05 + col * 0.45
            y = 0.72 - row * 0.20
            ax.text(x, y + 0.04, lbl, transform=ax.transAxes,
                    fontsize=5, color=PColor.TEXT_LABEL, va="bottom", family="sans-serif")
            v = ax.text(x, y - 0.04, "--", transform=ax.transAxes,
                        fontsize=7, fontweight="bold", color=PColor.TEXT_VALUE,
                        va="top", family="monospace")
            self._n_vals[lbl] = v

    def _update_nav(self, planner, mission, wp, eta, path_len, explored):
        vals = {
            "PLANNER": planner[:10], "MISSION": mission[:11],
            "WAYPOINTS": f"{wp}", "ETA": eta,
            "PATH LEN": f"{path_len:.0f}m", "EXPLORED": f"{explored:.1f}%",
        }
        for key, v in vals.items():
            if key in self._n_vals:
                self._n_vals[key].set_text(v)

    # ══════════════════════════════════════════════════════════════════════════
    # BATTERY CARD
    # ══════════════════════════════════════════════════════════════════════════

    def _create_battery_card(self):
        ax = self._ax_battery
        ax.text(0.05, 0.90, "BATTERY & STATUS", transform=ax.transAxes,
                fontsize=7, fontweight="bold", color=PColor.SUCCESS,
                va="top", family="sans-serif")
        ax.plot([0.05, 0.95], [0.82, 0.82], transform=ax.transAxes,
                color=PColor.BORDER, linewidth=0.5)

        # Battery bar
        self._bat_bar_bg = FancyBboxPatch(
            (0.08, 0.30), 0.84, 0.22,
            boxstyle=mpatches.BoxStyle("Round", pad=0.04),
            facecolor=PColor.BG_INNER, edgecolor=PColor.BORDER,
            linewidth=0.8, transform=ax.transAxes,
        )
        ax.add_patch(self._bat_bar_bg)
        self._bat_bar_fill = FancyBboxPatch(
            (0.10, 0.33), 0.50, 0.16,
            boxstyle=mpatches.BoxStyle("Round", pad=0.03),
            facecolor=PColor.SUCCESS, edgecolor="none",
            transform=ax.transAxes, alpha=0.85,
        )
        ax.add_patch(self._bat_bar_fill)
        self._bat_pct = ax.text(0.50, 0.41, "100%", transform=ax.transAxes,
                                fontsize=14, fontweight="bold", color=PColor.TEXT_MAIN,
                                ha="center", va="center", family="monospace")

        self._bat_status = ax.text(0.50, 0.12, "SYSTEM NOMINAL", transform=ax.transAxes,
                                    fontsize=6, fontweight="bold", color=PColor.SUCCESS,
                                    ha="center", va="center", family="monospace")
        self._bat_emergency = ax.text(0.08, 0.60, "EMERGENCY: NORMAL", transform=ax.transAxes,
                                       fontsize=5.5, color=PColor.SUCCESS, va="center", family="monospace")

    # ══════════════════════════════════════════════════════════════════════════
    # MISSION CARD
    # ══════════════════════════════════════════════════════════════════════════

    def _create_mission_card(self):
        ax = self._ax_mission
        ax.text(0.05, 0.90, "MISSION OVERVIEW", transform=ax.transAxes,
                fontsize=7, fontweight="bold", color=PColor.PURPLE,
                va="top", family="sans-serif")
        ax.plot([0.05, 0.95], [0.82, 0.82], transform=ax.transAxes,
                color=PColor.BORDER, linewidth=0.5)

        labels = ["START", "TARGET", "PROGRESS", "DIST REMAIN",
                  "AVG SPEED", "TIME ELAPSED"]
        self._m_vals = {}
        for i, lbl in enumerate(labels):
            col = i % 2
            row = i // 2
            x = 0.05 + col * 0.45
            y = 0.72 - row * 0.18
            ax.text(x, y + 0.04, lbl, transform=ax.transAxes,
                    fontsize=5, color=PColor.TEXT_LABEL, va="bottom", family="sans-serif")
            v = ax.text(x, y - 0.04, "--", transform=ax.transAxes,
                        fontsize=7, fontweight="bold", color=PColor.TEXT_VALUE,
                        va="top", family="monospace")
            self._m_vals[lbl] = v

    # ══════════════════════════════════════════════════════════════════════════
    # METRICS GRAPH
    # ══════════════════════════════════════════════════════════════════════════

    def _create_metrics(self):
        ax = self._ax_metrics
        ax.text(0.01, 0.93, "LIVE PERFORMANCE", transform=ax.transAxes,
                fontsize=7, fontweight="bold", color=PColor.TEXT_VALUE,
                va="top", family="sans-serif")

        cols = [PColor.LINE_RISK, PColor.LINE_MEMORY, PColor.LINE_ATTENTION,
                PColor.LINE_COGNITIVE, PColor.LINE_BATTERY, PColor.LINE_SPEED,
                PColor.LINE_CONFIDENCE]
        names = ["Risk", "Memory", "Attention", "Cognitive", "Battery", "Speed", "Confidence"]
        self._m_lines = []
        for c, n in zip(cols, names):
            ln = ax.plot([], [], color=c, linewidth=0.8, label=n, alpha=0.85)[0]
            self._m_lines.append(ln)

        leg = ax.legend(loc="upper right", fontsize=4.5, frameon=True, framealpha=0.7,
                        facecolor=PColor.BG_INNER, edgecolor=PColor.BORDER,
                        labelcolor=PColor.TEXT_SECTION, ncol=7, columnspacing=1.0)
        for t in leg.get_texts():
            t.set_fontsize(5)
        ax.set_xlabel("Frame", color=PColor.TEXT_DIM, fontsize=5)
        ax.set_ylabel("Value", color=PColor.TEXT_DIM, fontsize=5)

    # ══════════════════════════════════════════════════════════════════════════
    # DRONE BRAIN PANEL
    # ══════════════════════════════════════════════════════════════════════════

    def _create_brain(self):
        ax = self._ax_brain
        # Title
        ax.text(0.03, 0.97, "DRONE BRAIN — LIVE", transform=ax.transAxes,
                fontsize=8, fontweight="bold", color=PColor.DRONE,
                va="top", family="sans-serif")

        # Decision & Mission
        self._b_decision = ax.text(0.03, 0.89, "DECISION: NAVIGATE", transform=ax.transAxes,
                                    fontsize=6, fontweight="bold", color=PColor.SUCCESS,
                                    va="top", family="monospace")
        self._b_mission = ax.text(0.55, 0.89, "MISSION: GO", transform=ax.transAxes,
                                   fontsize=6, fontweight="bold", color=PColor.INFO,
                                   va="top", family="monospace")

        # Separator
        ax.plot([0.03, 0.97], [0.85, 0.85], color=PColor.BORDER,
                linewidth=0.3, transform=ax.transAxes)

        # Engines (2x4 grid, compact)
        engines = [
            ("PERCEPTION", PColor.PRIMARY), ("BEHAVIOR", PColor.WARNING),
            ("MEMORY", PColor.LINE_MEMORY), ("EMERGENCY", PColor.DANGER),
            ("PLANNING", PColor.SUCCESS), ("RISK", PColor.DANGER),
            ("FUSION", PColor.INFO), ("MOTION", PColor.SUCCESS),
        ]
        self._b_engines = []
        for i, (name, color) in enumerate(engines):
            col = i % 2
            row = i // 2
            x = 0.03 + col * 0.45
            y = 0.81 - row * 0.075
            lbl = ax.text(x, y, name, transform=ax.transAxes,
                          fontsize=5, fontweight="bold", color=PColor.TEXT_SECTION,
                          va="top", family="sans-serif")
            dot = ax.plot(x + 0.16, y - 0.01, "o", markersize=2.5,
                          color=PColor.STATUS_OK, transform=ax.transAxes)[0]
            bar_bg = FancyBboxPatch(
                (x + 0.20, y - 0.028), 0.15, 0.018,
                boxstyle=mpatches.BoxStyle("Round", pad=0.003),
                facecolor=PColor.BG_INNER, edgecolor=PColor.BORDER,
                linewidth=0.3, transform=ax.transAxes,
            )
            ax.add_patch(bar_bg)
            bar_fill = FancyBboxPatch(
                (x + 0.205, y - 0.026), 0.10, 0.014,
                boxstyle=mpatches.BoxStyle("Round", pad=0.002),
                facecolor=color, edgecolor="none",
                transform=ax.transAxes, alpha=0.8,
            )
            ax.add_patch(bar_fill)
            pct = ax.text(x + 0.36, y - 0.01, "95%", transform=ax.transAxes,
                          fontsize=5, fontweight="bold", color=PColor.TEXT_VALUE,
                          va="center", family="monospace")
            self._b_engines.append((lbl, dot, bar_fill, pct, name))

    # ══════════════════════════════════════════════════════════════════════════
    # SENSORS PANEL
    # ══════════════════════════════════════════════════════════════════════════

    def _create_sensors(self):
        ax = self._ax_sensors
        ax.text(0.03, 0.97, "SENSOR STATUS", transform=ax.transAxes,
                fontsize=7, fontweight="bold", color=PColor.SECONDARY,
                va="top", family="sans-serif")
        ax.plot([0.03, 0.97], [0.93, 0.93], color=PColor.BORDER,
                linewidth=0.3, transform=ax.transAxes)

        sensors = [
            ("RGB CAM", True), ("DEPTH", True), ("LIDAR", True),
            ("THERMAL", True), ("GPS", True), ("IMU", True),
            ("COMPASS", True), ("RADAR", True), ("ULTRASONIC", True),
        ]
        for i, (name, ok) in enumerate(sensors):
            col = i % 3
            row = i // 3
            x = 0.03 + col * 0.32
            y = 0.88 - row * 0.12
            ax.text(x, y, "●", transform=ax.transAxes,
                    fontsize=6, color=PColor.STATUS_OK if ok else PColor.STATUS_ERR,
                    va="top", family="sans-serif")
            ax.text(x + 0.06, y, name, transform=ax.transAxes,
                    fontsize=5, color=PColor.TEXT_SECTION,
                    va="top", family="sans-serif")

            # Sub-stats
            stats = f"OK  |  30Hz  |  5ms"
            ax.text(x + 0.06, y - 0.035, stats, transform=ax.transAxes,
                    fontsize=4, color=PColor.TEXT_DIM, va="top", family="monospace")

    # ══════════════════════════════════════════════════════════════════════════
    # UPDATE METHODS
    # ══════════════════════════════════════════════════════════════════════════

    def _update_fps(self):
        now = time.perf_counter()
        dt = now - self._last_t
        self._last_t = now
        if dt > 0:
            self._fps += FPS_SMOOTH * (1.0 / dt - self._fps)
        self._actual_dt = max(0.016, min(dt, 0.5))

    def update(self, world=None, drone=None, target=None, path=None,
               smooth_path=None, occupancy_grid=None, perception_map=None,
               risk_map=None, memory_map=None, context_map=None,
               cognitive_map=None, premium_world=None,
               behavior_state="--", mission_state="--", planner_name="--",
               emergency_state="NORMAL", battery_percentage=100.0,
               memory_density=0.0, active_cells=0, explored_percent=0.0,
               camera_mode=None, brain_log=None,
               drone_speed=None, drone_altitude=None,
               battery_drain_rate=None, visible_obstacles=None,
               weather_fx=None, **kwargs):
        self._update_fps()
        self._frame_count += 1
        dt = self._actual_dt

        self.vision.update(dt)

        drone_x = float(getattr(drone, "x", 50.0)) if drone else 50.0
        drone_y = float(getattr(drone, "y", 50.0)) if drone else 50.0
        drone_heading = float(getattr(drone, "heading", 0.0)) if drone else 0.0

        if camera_mode is not None:
            self.camera.set_mode(camera_mode, instant=False)
        self.camera.update(drone_x, drone_y, drone_heading, dt)

        if target is not None:
            tx, ty = (float(target[0]), float(target[1])) if hasattr(target, '__getitem__') else (50.0, 50.0)
        else:
            tx, ty = 50.0, 50.0

        # Update all panels
        self._update_viewport(world, drone, target, path, smooth_path,
                              premium_world, occupancy_grid,
                              drone_x, drone_y, tx, ty, drone_heading)
        self._update_topbar(drone, behavior_state, mission_state, emergency_state)
        self._update_flight_card(drone, drone_x, drone_y, tx, ty, dt)
        self._update_nav_card(planner_name, mission_state, path, explored_percent)
        self._update_battery_card(battery_percentage, emergency_state)
        self._update_mission_card(drone, drone_x, drone_y, tx, ty)
        self._update_metrics_graph(drone, target, battery_percentage, explored_percent, memory_density)
        self._update_brain_panel(brain_log, behavior_state, planner_name,
                                 mission_state, emergency_state, visible_obstacles)
        self._blit()

    def _update_topbar(self, drone, behavior, mission, emergency):
        self._tb_fps.set_text(f"{self._fps:.0f} FPS  |  Frame {self._frame_count}")
        sim_time = time.time() - self.mission_start_time
        mins = int(sim_time // 60)
        secs = int(sim_time % 60)
        self._tb_time.set_text(f"{mins:02d}:{secs:02d}")

    def _update_viewport(self, world, drone, target, path, smooth_path,
                         premium_world, occ_grid, dx, dy, tx, ty, heading):
        ax = self._ax_viewport
        ww = self.world_width
        wh = self.world_height
        ax.set_xlim(-1, ww + 1)
        ax.set_ylim(-1, wh + 1)

        # Terrain
        if premium_world is not None:
            try:
                terrain = premium_world.get_terrain_array()
                self._v_terrain.set_data(terrain)
                self._v_terrain.set_extent([-0.5, ww - 0.5, -0.5, wh - 0.5])
                self._v_terrain.set_alpha(1.0)

                elev = premium_world.get_elevation_array()
                self._v_topo.set_data(elev)
                self._v_topo.set_extent([-0.5, ww - 0.5, -0.5, wh - 0.5])
            except:
                pass

            # Buildings
            bld = [(b.x + b.width/2, b.y + b.height/2) for b in premium_world.buildings]
            self._v_buildings.set_offsets(np.array(bld) if bld else np.empty((0, 2)))
            self._v_buildings.set_sizes([max(5, b.width * b.height * 8) for b in premium_world.buildings] if bld else [20])

            # Trees
            tree_pts = []
            for forest in premium_world.forests:
                tree_pts.extend(forest.tree_positions)
            self._v_trees.set_offsets(np.array(tree_pts) if tree_pts else np.empty((0, 2)))

            # Pads
            pads = [(p.x, p.y) for p in premium_world.landing_pads]
            self._v_pads.set_offsets(np.array(pads) if pads else np.empty((0, 2)))

            # Vehicles
            veh = [(v.x, v.y) for v in premium_world.vehicles]
            self._v_vehicles.set_offsets(np.array(veh) if veh else np.empty((0, 2)))

            # Pedestrians
            ped = [(p.x, p.y) for p in premium_world.pedestrians]
            self._v_pedestrians.set_offsets(np.array(ped) if ped else np.empty((0, 2)))

            # Birds
            bird = [(b.x, b.y) for b in premium_world.birds]
            self._v_birds.set_offsets(np.array(bird) if bird else np.empty((0, 2)))
        else:
            for s in [self._v_buildings, self._v_trees, self._v_pads,
                       self._v_vehicles, self._v_pedestrians, self._v_birds]:
                s.set_offsets(np.empty((0, 2)))

        # Obstacles
        obs = getattr(world, "obstacles", set()) if world else set()
        self._v_obstacles.set_offsets(np.array(list(obs)) if obs else np.empty((0, 2)))
        dyn = getattr(world, "dynamic_obstacles", []) if world else []
        self._v_dynamic.set_offsets(np.array([(o.x, o.y) for o in dyn]) if dyn else np.empty((0, 2)))

        # Path
        dp = smooth_path or path
        if dp and len(dp) > 0:
            pa = np.asarray(dp)
            self._v_path.set_data(pa[:, 0], pa[:, 1])
            self._v_path_glow.set_data(pa[:, 0], pa[:, 1])
        else:
            self._v_path.set_data([], [])
            self._v_path_glow.set_data([], [])

        # Trail
        self.trail.append((dx, dy))
        self.trail = self.trail[-MAX_TRAIL:]
        if self.trail:
            ta = np.asarray(self.trail)
            self._v_trail.set_data(ta[:, 0], ta[:, 1])

        # Sensor
        self._v_sensor.center = (dx, dy)
        self._v_sensor_fill.center = (dx, dy)

        # Drone
        self._v_drone_body.center = (dx, dy)
        self._v_drone_glow.center = (dx, dy)
        hl = 2.0
        self._v_drone_heading.set_data(
            [dx, dx + hl * math.cos(heading)],
            [dy, dy + hl * math.sin(heading)],
        )

        # Target
        self._v_target_cross.set_data([tx], [ty])
        self._v_target_glow.center = (tx, ty)

        # Camera
        self._v_cam_badge.set_text(self.camera.get_mode_name())
        self._v_fps.set_text(f"{self._fps:.0f} FPS  |  {self._frame_count}")
        self._v_coords.set_text(f"({dx:.1f}, {dy:.1f})")

    def _update_flight_card(self, drone, dx, dy, tx, ty, dt):
        speed = float(getattr(drone, "speed", 0.0)) if drone else 0.0
        heading_deg = (float(getattr(drone, "heading", 0.0)) * 180.0 / math.pi) % 360.0 if drone else 0.0
        dist = math.hypot(tx - dx, ty - dy)
        if len(self.trail) >= 2:
            px, py = self.trail[-2]
            v_speed = math.hypot(dx - px, dy - py) / max(dt, 0.001)
        else:
            v_speed = speed
        bank = math.degrees(math.atan2(v_speed * 0.1, 9.81)) if v_speed > 0.5 else 0.0
        signal = max(50, int(100 - dist * 0.5))
        self._update_flight(speed, heading_deg, dist, v_speed, bank, signal)

    def _update_nav_card(self, planner, mission, path, explored):
        pl = len(path) if path else 0
        path_dist = pl * 1.2
        if pl > 0:
            eta_sec = int(path_dist / 2.0)
            eta = f"{eta_sec // 60}:{eta_sec % 60:02d}"
        else:
            eta = "AT TARGET"
        self._update_nav(planner or "--", mission or "--", pl, eta, path_dist, explored or 0)

    def _update_battery_card(self, pct, emergency):
        pct = min(100, max(0, pct or 0))
        w = 0.80 * (pct / 100.0)
        col = PColor.SUCCESS if pct > 50 else (PColor.WARNING if pct > 20 else PColor.DANGER)
        st = "SYSTEM NOMINAL" if pct > 50 else ("LOW BATTERY" if pct > 20 else "CRITICAL")
        self._bat_bar_fill.set_width(w)
        self._bat_bar_fill.set_facecolor(col)
        self._bat_pct.set_text(f"{pct:.0f}%")
        self._bat_pct.set_color(col)
        self._bat_status.set_text(st)
        self._bat_status.set_color(col)
        es = str(emergency or "NORMAL")
        ec = PColor.DANGER if "CRITICAL" in es else (PColor.WARNING if "LOW" in es else PColor.SUCCESS)
        self._bat_emergency.set_text(f"EMERGENCY: {es[:12]}")
        self._bat_emergency.set_color(ec)

    def _update_mission_card(self, drone, dx, dy, tx, ty):
        dist = math.hypot(tx - dx, ty - dy)
        total = math.hypot(tx - 5, ty - 5)
        progress = max(0, min(100, (1 - dist / max(total, 0.1)) * 100))
        speed = float(getattr(drone, "speed", 0.0)) if drone else 0.0
        elapsed = time.time() - self.mission_start_time
        mins = int(elapsed // 60)
        secs = int(elapsed % 60)
        vals = {
            "START": "(5, 5)", "TARGET": f"({tx:.0f}, {ty:.0f})",
            "PROGRESS": f"{progress:.1f}%", "DIST REMAIN": f"{dist:.0f}m",
            "AVG SPEED": f"{speed:.1f} m/s", "TIME ELAPSED": f"{mins}:{secs:02d}",
        }
        for key, v in vals.items():
            if key in self._m_vals:
                self._m_vals[key].set_text(v)

    def _update_metrics_graph(self, drone, target, bat_pct, explored, mem_d):
        risk = 0.3
        mem = (mem_d or 0) / 100.0
        cog = (explored or 0) / 100.0
        bat_n = (bat_pct or 100) / 100.0
        spd_n = float(getattr(drone, "speed", 0.0)) / 5.0 if drone else 0.0
        att = 0.75 + 0.15 * math.sin(self._frame_count * 0.05)
        conf = 0.88

        self._h_risk.append(risk)
        self._h_mem.append(mem)
        self._h_att.append(att)
        self._h_cog.append(cog)
        self._h_bat.append(bat_n)
        self._h_spd.append(spd_n)
        self._h_conf.append(conf)

        for h in [self._h_risk, self._h_mem, self._h_att, self._h_cog,
                  self._h_bat, self._h_spd, self._h_conf]:
            if len(h) > MAX_HISTORY:
                del h[:len(h) - MAX_HISTORY]

        n = len(self._h_risk)
        x = np.arange(n)
        data = [self._h_risk, self._h_mem, self._h_att, self._h_cog,
                self._h_bat, self._h_spd, self._h_conf]
        for ln, h in zip(self._m_lines, data):
            ln.set_data(x, h)
        self._ax_metrics.set_xlim(max(0, n - MAX_HISTORY), max(MAX_HISTORY, n))

    def _update_brain_panel(self, brain_log, behavior, planner, mission, emergency, obs):
        if not brain_log:
            return
        latest = brain_log[-1]
        dc = PColor.WARNING if behavior == "AVOID" else (PColor.SUCCESS if behavior == "NAVIGATE" else PColor.DANGER if behavior == "RETURN_HOME" else PColor.TEXT_DIM)
        self._b_decision.set_text(f"DECISION: {behavior}")
        self._b_decision.set_color(dc)
        self._b_mission.set_text(f"MISSION: {mission}")

        path_len = latest.get("path_len", 0)
        explored = latest.get("explored", 0)
        obs_c = obs if obs else 0

        effs = {
            "PERCEPTION": min(99, max(30, 90 - obs_c * 2)),
            "BEHAVIOR": 98 if behavior == "NAVIGATE" else 85,
            "MEMORY": min(95, max(40, int(explored * 0.8 + 20))),
            "EMERGENCY": 99 if emergency == "NORMAL" else 60,
            "PLANNING": min(99, max(40, 95 if path_len > 0 else 10)),
            "RISK": min(95, max(50, 70 + obs_c * 3)),
            "FUSION": 92 if behavior != "IDLE" else 25,
            "MOTION": 90 if behavior == "NAVIGATE" else 70,
        }
        for lbl, dot, bar, pct, name in self._b_engines:
            eff = effs.get(name, 80)
            c = PColor.SUCCESS if eff > 80 else (PColor.WARNING if eff > 50 else PColor.DANGER)
            dot.set_color(c)
            bar.set_width(0.14 * (eff / 100.0))
            bar.set_facecolor(c)
            pct.set_text(f"{eff}%")

    def _blit(self):
        if not self._init_done:
            return
        try:
            if self._bg_cache is not None:
                self.fig.canvas.restore_region(self._bg_cache)
                for ax in self._all_axes:
                    self.fig.canvas.blit(ax.bbox)
            else:
                self.fig.canvas.draw_idle()
        except:
            self.fig.canvas.draw_idle()
        self.fig.canvas.flush_events()

    def switch_camera(self):
        self.camera.cycle_mode()

    def close(self):
        plt.close(self.fig)


# ══════════════════════════════════════════════════════════════════════════════
# MODULE-LEVEL draw_premium()
# ══════════════════════════════════════════════════════════════════════════════

def draw_premium(world=None, drone=None, target=None, path=None, smooth_path=None,
                 occupancy_grid=None, sensor_radius=8, perception_map=None,
                 risk_map=None, memory_map=None, behavior_state=None,
                 mission_state=None, planner_name=None, emergency_state=None,
                 battery_percentage=None, memory_density=None, active_cells=None,
                 context_map=None, cognitive_map=None, explored_percent=None,
                 premium_world=None, camera_mode=None, living_world=None,
                 brain_log=None, drone_speed=None, drone_altitude=None,
                 battery_drain_rate=None, visible_obstacles=None,
                 weather_fx=None) -> None:
    global _premium_dashboard
    if _premium_dashboard is None or not plt.fignum_exists(_premium_dashboard.fig.number):
        _premium_dashboard = PremiumDashboard()
    _premium_dashboard.update(
        world=world, drone=drone, target=target, path=path, smooth_path=smooth_path,
        occupancy_grid=occupancy_grid, perception_map=perception_map,
        risk_map=risk_map, memory_map=memory_map, context_map=context_map,
        cognitive_map=cognitive_map, premium_world=premium_world,
        behavior_state=behavior_state or "--", mission_state=mission_state or "--",
        planner_name=planner_name or "--", emergency_state=emergency_state or "NORMAL",
        battery_percentage=battery_percentage or 0,
        memory_density=memory_density or 0, active_cells=active_cells or 0,
        explored_percent=explored_percent or 0, camera_mode=camera_mode,
        living_world=living_world, brain_log=brain_log,
        drone_speed=drone_speed, drone_altitude=drone_altitude,
        battery_drain_rate=battery_drain_rate,
        visible_obstacles=visible_obstacles, weather_fx=weather_fx,
    )


def reset_premium_dashboard():
    global _premium_dashboard
    if _premium_dashboard is not None:
        try:
            plt.close(_premium_dashboard.fig)
        except Exception:
            pass
        _premium_dashboard = None