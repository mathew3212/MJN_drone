"""
MJN Autonomous Drone Navigation System
=======================================
A comprehensive drone navigation simulation with:
- Sensor fusion and perception mapping
- Occupancy grid mapping with exploration tracking
- Memory management with decay and reinforcement
- Context-aware cost maps for path planning
- Risk prediction and trajectory forecasting
- Cognitive state estimation
- Behavior tree-based autonomous decision making
- Battery and emergency management
- Professional dashboard visualization
"""

__version__ = "1.0.0"
__author__ = "MJN Autonomous Systems"