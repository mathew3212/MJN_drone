# NAVIGATION_REPORT.md
## Mission Efficiency
- **Total Steps**: 95
- **Total Distance Travelled**: 0.00 units
- **Target Reach Time (steps)**: N/A
- **Return Home Time (steps)**: N/A
- **Path Efficiency**: 0.00%
- **Average Speed**: 0.00 units/step
- **Replans**: 0
- **Problems Detected**: 95

## Detected Issues
### Stuck States
#### Stuck Event 1
- **Cause**: Drone detected as stuck (minimal movement over 0 frames).
- **Location**: (90, 90) at step 57
- **Fix**: Automatic replanning initiated.
### Orbiting
#### Orbiting Event 1
- **Cause**: Drone moving in a circular pattern without significant progress.
- **Location**: (90, 90) at step 47
- **Fix**: Re-evaluate local planning and obstacle avoidance logic.
### Path Loops
#### Path Loop Event 1
- **Cause**: Drone repeating a segment of its path.
- **Location**: (90, 90) at step 57
- **Fix**: Adjust global or local planner to avoid redundant paths.
#### Path Loop Event 2
- **Cause**: Drone repeating a segment of its path.
- **Location**: (90, 90) at step 58
- **Fix**: Adjust global or local planner to avoid redundant paths.
#### Path Loop Event 3
- **Cause**: Drone repeating a segment of its path.
- **Location**: (85, 90) at step 59
- **Fix**: Adjust global or local planner to avoid redundant paths.
### Slowdowns
#### Slowdown Event 1
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 5, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 2
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 6, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 3
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 7, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 4
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 8, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 5
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 9, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 6
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 10, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 7
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 11, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 8
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 12, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 9
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 13, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 10
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 14, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 11
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 15, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 12
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 16, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 13
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 17, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 14
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 18, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 15
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 19, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 16
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 20, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 17
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 21, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 18
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 22, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 19
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 23, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 20
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 24, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 21
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 25, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 22
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 26, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 23
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 27, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 24
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 28, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 25
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 29, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 26
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 30, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 27
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 31, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 28
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 32, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 29
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 33, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 30
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 34, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 31
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 35, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 32
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 36, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 33
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 37, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 34
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 38, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 35
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 39, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 36
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 40, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 37
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 41, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 38
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 42, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 39
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 43, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 40
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 44, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 41
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 45, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 42
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 46, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 43
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 47, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 44
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 48, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 45
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 49, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 46
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 50, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 47
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 51, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 48
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 52, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 49
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 53, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 50
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 54, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 51
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 55, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 52
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 56, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 53
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 57, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 54
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 58, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 55
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 59, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 56
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 60, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 57
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 61, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 58
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 62, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 59
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 63, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 60
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 64, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 61
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 65, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 62
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 66, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 63
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 67, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 64
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 68, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 65
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 69, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 66
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 70, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 67
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 71, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 68
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 72, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 69
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 73, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 70
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 74, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 71
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 75, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 72
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 76, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 73
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 77, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 74
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 78, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 75
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 79, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 76
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 80, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 77
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 81, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 78
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 82, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 79
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 83, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 80
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 84, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 81
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 85, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 82
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 86, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 83
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 87, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 84
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 88, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 85
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 89, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 86
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 90, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 87
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 91, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 88
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 92, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 89
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 93, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 90
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 94, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
#### Slowdown Event 91
- **Cause**: Drone speed consistently below 0.1 for 5 steps.
- **Location**: At step 95, speed was 0.00
- **Fix**: Investigate local obstacles or pathing issues.
